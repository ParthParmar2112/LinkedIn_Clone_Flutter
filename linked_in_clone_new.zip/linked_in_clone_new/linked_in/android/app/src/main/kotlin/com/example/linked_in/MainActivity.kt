package com.example.linked_in

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
